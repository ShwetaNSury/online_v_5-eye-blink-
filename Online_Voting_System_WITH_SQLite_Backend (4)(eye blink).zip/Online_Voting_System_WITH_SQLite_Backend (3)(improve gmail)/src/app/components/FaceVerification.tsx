import { useRef, useState, useCallback, useEffect } from "react";
import Webcam from "react-webcam";
import { Button } from "./ui/button";
import { Camera, CheckCircle, XCircle, Image, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface FaceVerificationProps {
  storedFacePhoto: string;
  onVerificationComplete: (success: boolean, similarity: number) => void;
  threshold?: number; // Similarity threshold (0-100)
  requiredBlinks?: number;
}

export function FaceVerification({ 
  storedFacePhoto, 
  onVerificationComplete,
  threshold = 70 
  , requiredBlinks = 3
}: FaceVerificationProps) {
  const webcamRef = useRef<Webcam>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState(false);
  const [blinkCount, setBlinkCount] = useState(0);
  const lastEyeMean = useRef<number | null>(null);
  const lastBlinkAt = useRef<number>(0);
  const samplingInterval = useRef<number | null>(null);

  const simulateFaceComparison = (img1: string, img2: string): number => {
    // Mock similarity score between 70-95% for demo purposes
    // In a real app, you'd use a face recognition library or API
    return Math.floor(Math.random() * 25) + 70;
  };

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      setCapturedImage(imageSrc);
      toast.success("Face captured!");
    } else {
      toast.error("Failed to capture image. Please try again.");
    }
  }, [webcamRef]);

  // Blink detection: sample the eye region and look for rapid changes
  useEffect(() => {
    if (!webcamRef.current || !isCameraReady || cameraError) return;

    const video = webcamRef.current.video as HTMLVideoElement | undefined;
    if (!video) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const sample = () => {
      try {
        const w = video.videoWidth || 320;
        const h = video.videoHeight || 240;
        canvas.width = w;
        canvas.height = h;

        // draw current frame
        ctx.drawImage(video, 0, 0, w, h);

        // approximate eye region: horizontally center, upper-middle area
        const eyeX = Math.floor(w * 0.25);
        const eyeY = Math.floor(h * 0.25);
        const eyeW = Math.floor(w * 0.5);
        const eyeH = Math.floor(h * 0.18);

        const imgData = ctx.getImageData(eyeX, eyeY, eyeW, eyeH);
        const data = imgData.data;
        let sum = 0;
        for (let i = 0; i < data.length; i += 4) {
          // grayscale
          const gray = (data[i] + data[i+1] + data[i+2]) / 3;
          sum += gray;
        }
        const mean = sum / (data.length / 4);

        const prev = lastEyeMean.current;
        if (prev !== null) {
          const diff = Math.abs(mean - prev);
          const now = Date.now();
          // threshold tuned empirically; cooldown prevents double counting
          if (diff > 12 && now - lastBlinkAt.current > 600) {
            lastBlinkAt.current = now;
            setBlinkCount((c) => c + 1);
          }
        }
        lastEyeMean.current = mean;
      } catch (e) {
        // ignore
      }
    };

    // start sampling
    samplingInterval.current = window.setInterval(sample, 150);

    return () => {
      if (samplingInterval.current) {
        clearInterval(samplingInterval.current);
        samplingInterval.current = null;
      }
      lastEyeMean.current = null;
    };
  }, [isCameraReady, cameraError]);



  const verify = async () => {
    if (!capturedImage) {
      toast.error("Please capture a photo first");
      return;
    }
    if (blinkCount < requiredBlinks) {
      toast.error(`Please blink at least ${requiredBlinks} times. Detected: ${blinkCount}`);
      return;
    }

    setIsVerifying(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    const similarity = simulateFaceComparison(storedFacePhoto, capturedImage);
    const success = similarity >= threshold;

    setIsVerifying(false);

    if (success) {
      toast.success(`Face verified! Match: ${similarity}%`);
      onVerificationComplete(true, similarity);
    } else {
      toast.error(`Verification failed. Match: ${similarity}% (Required: ${threshold}%)`);
      onVerificationComplete(false, similarity);
    }
  };

  const retake = () => {
    setCapturedImage(null);
    setCameraError(false);
    setBlinkCount(0);
  };

  const handleUserMedia = () => {
    setIsCameraReady(true);
    setCameraError(false);
    setBlinkCount(0);
  };

  const handleUserMediaError = () => {
    setCameraError(true);
    toast.error("Camera access denied or not available");
  };

  const videoConstraints = {
    width: 1280,
    height: 720,
    facingMode: "user"
  };

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        {/* Stored Face */}
        <div className="space-y-2">
          <h4 className="font-medium text-center">Registered Photo</h4>
          <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
            <img src={storedFacePhoto} alt="Stored face" className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Current Capture */}
        <div className="space-y-2">
          <h4 className="font-medium text-center">Live Verification</h4>
          <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video">
            {!capturedImage ? (
              <>
                {!cameraError ? (
                  <>
                    <Webcam
                      ref={webcamRef}
                      audio={false}
                      screenshotFormat="image/jpeg"
                      videoConstraints={videoConstraints}
                      onUserMedia={handleUserMedia}
                      onUserMediaError={handleUserMediaError}
                      className="w-full h-full object-cover"
                    />
                    {!isCameraReady && (
                      <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
                        <div className="text-center">
                          <Camera className="size-8 mx-auto mb-2 text-gray-400 animate-pulse" />
                          <p className="text-sm text-gray-600">Loading camera...</p>
                        </div>
                      </div>
                    )}
                    {/* Blink counter UI */}
                    <div className="absolute left-3 top-3 bg-white/80 rounded-md px-3 py-1 text-sm">
                      Blinks: <strong>{blinkCount}</strong> / {requiredBlinks}
                    </div>
                  </>
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-200">
                    <div className="text-center p-4">
                      <Camera className="size-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-xs text-gray-600">Camera not available</p>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <img src={capturedImage} alt="Captured face" className="w-full h-full object-cover" />
            )}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-2">
        {!capturedImage ? (
          <>
            <Button
              onClick={capture}
              disabled={!isCameraReady || cameraError}
              className="flex-1"
              size="lg"
            >
              <Camera className="size-4 mr-2" />
              Capture Photo
            </Button>
          </>
        ) : (
          <>
            <Button
              onClick={retake}
              variant="outline"
              className="flex-1"
              size="lg"
            >
              Retake
            </Button>
            <Button
              onClick={verify}
              className="flex-1"
              size="lg"
              disabled={isVerifying}
            >
              {isVerifying ? (
                <>
                  <Loader2 className="size-4 mr-2 animate-spin" />
                  Verifying...
                </>
              ) : (
                <>
                  <CheckCircle className="size-4 mr-2" />
                  Verify Face
                </>
              )}
            </Button>
          </>
        )}
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
        <p className="text-xs text-blue-800">
          <strong>Note:</strong> The system will compare your live photo with your registered photo.
        </p>
      </div>
    </div>
  );
}