import { Vote, Shield, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";

export function ElectionHero() {
  return (
    <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-20">
      <div className="container mx-auto px-4">
        {/* Testing Guide Banner */}
        <div className="bg-yellow-500 text-gray-900 rounded-lg p-4 mb-8">
          <h3 className="font-semibold mb-2">🧪 Testing Guide - Sample Data Available</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="font-medium mb-1">Pre-registered Test Accounts:</p>
              <ul className="space-y-1">
                <li>• test.voter@example.com (VID: VID-2025-000001)</li>
                <li>• demo.user@example.com (VID: VID-2025-000002)</li>
                <li>• Admin: admin@election.com / admin123</li>
              </ul>
            </div>
            <div>
              <p className="font-medium mb-1">Testing Features:</p>
              <ul className="space-y-1">
                <li>• 3 pending registrations in admin panel</li>
                <li>• "Use Sample Photo" button for camera testing</li>
                <li>• Complete voter registration & approval workflow</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto text-center">
          <h1 className="mb-6">Secure & Transparent Election Voting System</h1>
          <p className="text-xl text-gray-300 mb-8">
            Empowering democratic participation through our secure, user-friendly digital voting platform. Cast your vote with confidence.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg">
              View Elections
            </Button>
            <Button size="lg" variant="outline">
              Register to Vote
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
            <div className="flex flex-col items-center text-center">
              <Shield className="size-10 text-blue-600 mb-2" />
              <span className="text-sm text-gray-600">Secure Platform</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <Vote className="size-10 text-blue-600 mb-2" />
              <span className="text-sm text-gray-600">Anonymous Voting</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <CheckCircle className="size-10 text-blue-600 mb-2" />
              <span className="text-sm text-gray-600">Verified System</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}