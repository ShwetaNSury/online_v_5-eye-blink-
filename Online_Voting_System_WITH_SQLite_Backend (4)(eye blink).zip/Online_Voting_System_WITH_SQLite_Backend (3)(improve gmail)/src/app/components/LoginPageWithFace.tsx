import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { toast } from "sonner";
import { Vote, Shield, Lock, Camera, ArrowLeft, CheckCircle, QrCode } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { FaceVerification } from "./FaceVerification";
import { QRCodeScanner } from "./QRCodeScanner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";

interface LoginPageWithFaceProps {
  onLogin: (email: string, password: string, role: "admin" | "voter") => void;
  onNavigateToRegister: () => void;
  onNavigateBack: () => void;
  getUserData: (email: string) => { facePhoto: string; voterId: string } | null;
}

export function LoginPageWithFace({ 
  onLogin, 
  onNavigateToRegister, 
  onNavigateBack,
  getUserData 
}: LoginPageWithFaceProps) {
  const [voterEmail, setVoterEmail] = useState("");
  const [voterPassword, setVoterPassword] = useState("");
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [showFaceVerification, setShowFaceVerification] = useState(false);
  const [storedFacePhoto, setStoredFacePhoto] = useState<string | null>(null);
  const [pendingLoginEmail, setPendingLoginEmail] = useState("");
  const [pendingLoginPassword, setPendingLoginPassword] = useState("");
  const [pendingVoterId, setPendingVoterId] = useState("");
  const [currentStep, setCurrentStep] = useState<"credentials" | "face" | "voterId">("credentials");
  const [showQRScanner, setShowQRScanner] = useState(false);

  const handleVoterLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!voterEmail || !voterPassword) {
      toast.error("Please fill in all fields");
      return;
    }

    // Check if user exists
    const userData = getUserData(voterEmail);
    if (!userData) {
      toast.error("User not found. Please register or wait for admin approval.");
      return;
    }

    // Proceed to face verification
    setStoredFacePhoto(userData.facePhoto);
    setPendingLoginEmail(voterEmail);
    setPendingLoginPassword(voterPassword);
    setPendingVoterId("");
    setCurrentStep("face");
    setShowFaceVerification(true);
  };

  const handleFaceVerificationComplete = (success: boolean, similarity: number) => {
    if (success) {
      setShowFaceVerification(false);
      toast.success("Face verified successfully!");
      // Move to voter ID verification step
      setCurrentStep("voterId");
    } else {
      toast.error("Face verification failed. Please try again.");
      setShowFaceVerification(false);
      setCurrentStep("credentials");
    }
  };

  const handleVoterIdSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const userData = getUserData(pendingLoginEmail);
    if (!userData) {
      toast.error("User data not found");
      return;
    }

    if (pendingVoterId !== userData.voterId) {
      toast.error("Invalid Voter ID. Please check your Voter ID card.");
      return;
    }

    // All verifications passed
    toast.success("All verifications passed! Logging in...");
    onLogin(pendingLoginEmail, pendingLoginPassword, "voter");
    resetForm();
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminEmail || !adminPassword) {
      toast.error("Please fill in all fields");
      return;
    }
    onLogin(adminEmail, adminPassword, "admin");
  };

  const resetForm = () => {
    setVoterEmail("");
    setVoterPassword("");
    setAdminEmail("");
    setAdminPassword("");
    setPendingLoginEmail("");
    setPendingLoginPassword("");
    setPendingVoterId("");
    setCurrentStep("credentials");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid md:grid-cols-2 gap-8 items-center">
        {/* Left side - Branding */}
        <div className="text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2 mb-6">
            <Vote className="size-12 text-blue-600" />
            <h1 className="text-4xl">ElectionHub</h1>
          </div>
          <p className="text-xl text-gray-600 mb-8">
            Secure, transparent, and accessible digital voting platform for democratic elections.
          </p>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Shield className="size-6 text-blue-600" />
              <span className="text-gray-700">Military-grade encryption</span>
            </div>
            <div className="flex items-center gap-3">
              <Lock className="size-6 text-blue-600" />
              <span className="text-gray-700">Anonymous & secure voting</span>
            </div>
            <div className="flex items-center gap-3">
              <Camera className="size-6 text-blue-600" />
              <span className="text-gray-700">Face recognition security</span>
            </div>
            <div className="flex items-center gap-3">
              <Vote className="size-6 text-blue-600" />
              <span className="text-gray-700">Real-time result tracking</span>
            </div>
          </div>
        </div>

        {/* Right side - Login Forms */}
        <Card className="shadow-2xl">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={onNavigateBack}
              >
                <ArrowLeft className="size-4 mr-2" />
                Back
              </Button>
            </div>
            <CardTitle>Login to ElectionHub</CardTitle>
            <CardDescription>
              Choose your role and login to continue
            </CardDescription>
          </CardHeader>
          <CardContent>
            {currentStep === "voterId" ? (
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                  <div className="flex items-center gap-2 text-green-700 mb-2">
                    <CheckCircle className="size-5" />
                    <span className="font-medium">Face Verified Successfully!</span>
                  </div>
                  <p className="text-sm text-green-600">
                    Final step: Enter your Voter ID or scan QR code
                  </p>
                </div>

                <form onSubmit={handleVoterIdSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="voter-id-input">Voter ID *</Label>
                    <Input
                      id="voter-id-input"
                      value={pendingVoterId}
                      onChange={(e) => setPendingVoterId(e.target.value)}
                      placeholder="VID-2025-001234"
                      className="mt-2"
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Enter the Voter ID from your digital Voter ID card
                    </p>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white px-2 text-gray-500">Or</span>
                    </div>
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => setShowQRScanner(true)}
                  >
                    <QrCode className="size-4 mr-2" />
                    Scan QR Code from Voter ID Card
                  </Button>

                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setCurrentStep("credentials");
                        resetForm();
                      }}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Complete Login
                    </Button>
                  </div>
                </form>
              </div>
            ) : (
              <Tabs defaultValue="voter" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="voter">Voter Login</TabsTrigger>
                  <TabsTrigger value="admin">Admin Login</TabsTrigger>
                </TabsList>

                <TabsContent value="voter" className="mt-6">
                  <form onSubmit={handleVoterLogin} className="space-y-4">
                    <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg mb-4">
                      <p className="text-sm text-blue-800">
                        <strong>Voter Login Process:</strong>
                      </p>
                      <ol className="text-sm text-blue-700 mt-2 space-y-1">
                        <li>1. Enter email & password</li>
                        <li>2. Face verification via webcam</li>
                        <li>3. Enter Voter ID number</li>
                      </ol>
                    </div>

                    <div>
                      <Label htmlFor="voter-email">Email Address</Label>
                      <Input
                        id="voter-email"
                        type="email"
                        value={voterEmail}
                        onChange={(e) => setVoterEmail(e.target.value)}
                        placeholder="your@email.com"
                        className="mt-2"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="voter-password">Password</Label>
                      <Input
                        id="voter-password"
                        type="password"
                        value={voterPassword}
                        onChange={(e) => setVoterPassword(e.target.value)}
                        placeholder="••••••••"
                        className="mt-2"
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full" size="lg">
                      <Camera className="size-4 mr-2" />
                      Continue to Face Verification
                    </Button>
                    <div className="text-center text-sm text-gray-600">
                      Don't have an account?{" "}
                      <button
                        type="button"
                        onClick={onNavigateToRegister}
                        className="text-blue-600 hover:underline font-semibold"
                      >
                        Register here
                      </button>
                    </div>
                  </form>
                </TabsContent>

                <TabsContent value="admin" className="mt-6">
                  <form onSubmit={handleAdminLogin} className="space-y-4">
                    <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg mb-4">
                      <p className="text-sm text-yellow-800">
                        <strong>Demo Admin Credentials:</strong><br />
                        Email: admin@election.com<br />
                        Password: admin123
                      </p>
                    </div>
                    <div>
                      <Label htmlFor="admin-email">Admin Email</Label>
                      <Input
                        id="admin-email"
                        type="email"
                        value={adminEmail}
                        onChange={(e) => setAdminEmail(e.target.value)}
                        placeholder="admin@election.com"
                        className="mt-2"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="admin-password">Admin Password</Label>
                      <Input
                        id="admin-password"
                        type="password"
                        value={adminPassword}
                        onChange={(e) => setAdminPassword(e.target.value)}
                        placeholder="••••••••"
                        className="mt-2"
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full" size="lg">
                      <Shield className="size-4 mr-2" />
                      Login as Admin
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Face Verification Dialog */}
      <Dialog open={showFaceVerification} onOpenChange={setShowFaceVerification}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Face Verification</DialogTitle>
            <DialogDescription>
              Please position your face in front of the camera for verification
            </DialogDescription>
          </DialogHeader>
          {storedFacePhoto && (
            <FaceVerification
              storedFacePhoto={storedFacePhoto}
              onVerificationComplete={handleFaceVerificationComplete}
              threshold={75}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* QR Code Scanner Dialog */}
      <Dialog open={showQRScanner} onOpenChange={setShowQRScanner}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Scan QR Code</DialogTitle>
            <DialogDescription>
              Please scan the QR code from your Voter ID card
            </DialogDescription>
          </DialogHeader>
          <QRCodeScanner
            onScanSuccess={(voterId) => {
              setPendingVoterId(voterId);
              setShowQRScanner(false);
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}