import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { toast } from "sonner";
import { UserCheck, UserX, Send, FileText, Eye, Download } from "lucide-react";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { VoterIDCard, VoterData } from "./VoterIDCard";

export interface PendingRegistration {
  id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  dateOfBirth: string;
  address: string;
  facePhoto: string;
  voterIdDocument: string;
  status: "pending" | "approved" | "rejected";
  registrationDate: string;
  generatedVoterId?: string;
}

interface VoterRegistrationManagementProps {
  registrations: PendingRegistration[];
  onApprove: (id: string, voterId: string) => void;
  onReject: (id: string, reason: string) => void;
}

export function VoterRegistrationManagement({
  registrations,
  onApprove,
  onReject,
}: VoterRegistrationManagementProps) {
  const [selectedRegistration, setSelectedRegistration] = useState<PendingRegistration | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [showGenerateId, setShowGenerateId] = useState(false);
  const [generatedVoterId, setGeneratedVoterId] = useState("");
  const [constituency, setConstituency] = useState("");
  const [pollingStation, setPollingStation] = useState("");
  const [showVoterCard, setShowVoterCard] = useState(false);
  const [voterCardData, setVoterCardData] = useState<VoterData | null>(null);

  const pendingRegistrations = registrations.filter(r => r.status === "pending");
  const approvedRegistrations = registrations.filter(r => r.status === "approved");
  const rejectedRegistrations = registrations.filter(r => r.status === "rejected");

  const handleViewDetails = (registration: PendingRegistration) => {
    setSelectedRegistration(registration);
    setShowDetails(true);
  };

  const handleGenerateVoterId = (registration: PendingRegistration) => {
    setSelectedRegistration(registration);
    // Auto-generate voter ID
    const timestamp = Date.now().toString().slice(-6);
    const randomPart = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    setGeneratedVoterId(`VID-2025-${timestamp}${randomPart}`);
    setShowGenerateId(true);
  };

  const handleApproveWithVoterId = () => {
    if (!selectedRegistration || !generatedVoterId || !constituency || !pollingStation) {
      toast.error("Please fill in all required fields");
      return;
    }

    // Create voter card data
    const voterCard: VoterData = {
      voterId: generatedVoterId,
      name: selectedRegistration.name,
      email: selectedRegistration.email,
      dateOfBirth: selectedRegistration.dateOfBirth,
      address: selectedRegistration.address,
      registrationDate: new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      }),
      photo: selectedRegistration.facePhoto,
      constituency,
      pollingStation,
    };

    setVoterCardData(voterCard);
    onApprove(selectedRegistration.id, generatedVoterId);
    setShowGenerateId(false);
    setShowVoterCard(true);
    toast.success("Voter approved and ID card generated!");
  };

  const handleSendVoterIdToEmail = () => {
    if (!voterCardData) return;
    (async () => {
      toast.loading("Checking backend connection...");
      
      // First check if backend is running
      const healthController = new AbortController();
      const healthTimeout = setTimeout(() => healthController.abort(), 5000);
      
      try {
        const healthCheck = await fetch('http://localhost:5000/api/health', {
          signal: healthController.signal
        });
        clearTimeout(healthTimeout);
        
        if (!healthCheck.ok) {
          throw new Error('Backend service not responding');
        }
      } catch (err: any) {
        clearTimeout(healthTimeout);
        toast.dismiss();
        toast.error('❌ Backend server not running. Start it with: npm start');
        console.error('Backend check failed:', err.message);
        return;
      }

      // Now send the voter ID
      toast.dismiss();
      toast.loading("Sending Voter ID card via email...");
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 60000); // 60 second timeout
      
      try {
        console.log('Sending voter data:', voterCardData);
        
        const resp = await fetch('http://localhost:5000/api/send-voter-id', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ voter: voterCardData }),
          signal: controller.signal,
        });
        
        clearTimeout(timeout);
        let data: any = null;
        try { data = await resp.json(); } catch { data = null; }
        
        console.log('Response status:', resp.status);
        console.log('Response data:', data);
        
        if (!resp.ok) {
          const errorMessage = data?.details || data?.error || `HTTP ${resp.status}`;
          throw new Error(errorMessage);
        }
        
        toast.dismiss();
        toast.success(`✅ Voter ID sent to ${voterCardData.email}`);
        setShowVoterCard(false);
        setVoterCardData(null);
        setSelectedRegistration(null);
        
      } catch (e: any) {
        clearTimeout(timeout);
        let errorMsg = 'Unknown error';
        
        if (e.name === 'AbortError') {
          errorMsg = 'Request timeout - check backend console for errors.';
        } else if (e.message.includes('Failed to fetch')) {
          errorMsg = 'Cannot reach backend server at localhost:5000. Make sure backend is running (npm start).';
        } else {
          errorMsg = e.message || String(e);
        }
        
        console.error('Send error:', errorMsg);
        toast.dismiss();
        toast.error('❌ ' + errorMsg);
      }
    })();
  };

  const handleReject = () => {
    if (!selectedRegistration) return;
    
    const reason = prompt("Enter rejection reason:");
    if (reason) {
      onReject(selectedRegistration.id, reason);
      setShowDetails(false);
      setSelectedRegistration(null);
      toast.success("Registration rejected");
    }
  };

  const downloadPendingAsExcel = async () => {
    if (pendingRegistrations.length === 0) {
      toast.error("No pending registrations to download");
      return;
    }

    try {
      // Dynamically import xlsx library
      const { utils, writeFile } = await import('xlsx');
      
      // Prepare data for Excel
      const excelData = pendingRegistrations.map((reg) => ({
        "Name": reg.name,
        "Email": reg.email,
        "Phone": reg.phone,
        "Date of Birth": reg.dateOfBirth,
        "Address": reg.address,
        "Registration Date": reg.registrationDate,
        "Status": reg.status
      }));

      // Create worksheet
      const worksheet = utils.json_to_sheet(excelData);
      
      // Set column widths
      worksheet['!cols'] = [
        { wch: 20 }, // Name
        { wch: 25 }, // Email
        { wch: 15 }, // Phone
        { wch: 15 }, // Date of Birth
        { wch: 30 }, // Address
        { wch: 15 }, // Registration Date
        { wch: 10 }  // Status
      ];

      // Create workbook
      const workbook = utils.book_new();
      utils.book_append_sheet(workbook, worksheet, "Pending Registrations");

      // Generate filename with timestamp
      const timestamp = new Date().toISOString().split('T')[0];
      const filename = `pending-registrations-${timestamp}.xlsx`;

      // Write file
      writeFile(workbook, filename);
      toast.success(`Downloaded ${pendingRegistrations.length} pending registrations`);
    } catch (error) {
      console.error('Error downloading Excel:', error);
      toast.error("Failed to download Excel file. Please ensure xlsx library is installed.");
    }
  };

  const downloadApprovedAsExcel = async () => {
    if (approvedRegistrations.length === 0) {
      toast.error("No approved registrations to download");
      return;
    }

    try {
      // Dynamically import xlsx library
      const { utils, writeFile } = await import('xlsx');
      
      // Prepare data for Excel
      const excelData = approvedRegistrations.map((reg) => ({
        "Name": reg.name,
        "Email": reg.email,
        "Phone": reg.phone,
        "Date of Birth": reg.dateOfBirth,
        "Address": reg.address,
        "Voter ID": reg.generatedVoterId || "N/A",
        "Registration Date": reg.registrationDate,
        "Status": reg.status
      }));

      // Create worksheet
      const worksheet = utils.json_to_sheet(excelData);
      
      // Set column widths
      worksheet['!cols'] = [
        { wch: 20 }, // Name
        { wch: 25 }, // Email
        { wch: 15 }, // Phone
        { wch: 15 }, // Date of Birth
        { wch: 30 }, // Address
        { wch: 20 }, // Voter ID
        { wch: 15 }, // Registration Date
        { wch: 10 }  // Status
      ];

      // Create workbook
      const workbook = utils.book_new();
      utils.book_append_sheet(workbook, worksheet, "Approved Registrations");

      // Generate filename with timestamp
      const timestamp = new Date().toISOString().split('T')[0];
      const filename = `approved-registrations-${timestamp}.xlsx`;

      // Write file
      writeFile(workbook, filename);
      toast.success(`Downloaded ${approvedRegistrations.length} approved registrations`);
    } catch (error) {
      console.error('Error downloading Excel:', error);
      toast.error("Failed to download Excel file. Please ensure xlsx library is installed.");
    }
  };

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Pending Registrations</CardDescription>
            <CardTitle className="text-3xl">{pendingRegistrations.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Approved Registrations</CardDescription>
            <CardTitle className="text-3xl text-green-600">{approvedRegistrations.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Rejected Registrations</CardDescription>
            <CardTitle className="text-3xl text-red-600">{rejectedRegistrations.length}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Pending Registrations List */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Pending Voter Registrations</CardTitle>
            <CardDescription>
              Review and approve or reject pending voter registrations
            </CardDescription>
          </div>
          <Button
            onClick={downloadPendingAsExcel}
            variant="outline"
            size="sm"
            disabled={pendingRegistrations.length === 0}
          >
            <Download className="size-4 mr-2" />
            Download Excel
          </Button>
        </CardHeader>
        <CardContent>
          {pendingRegistrations.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No pending registrations</p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingRegistrations.map((registration) => (
                <div
                  key={registration.id}
                  className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex gap-4 flex-1">
                      <img
                        src={registration.facePhoto}
                        alt={registration.name}
                        className="size-16 rounded-full object-cover border-2 border-gray-200"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{registration.name}</h3>
                        <p className="text-sm text-gray-600 mb-1">{registration.email}</p>
                        <p className="text-sm text-gray-600">{registration.phone}</p>
                        <p className="text-xs text-gray-500 mt-2">
                          Registered: {registration.registrationDate}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleViewDetails(registration)}
                      >
                        <Eye className="size-4 mr-2" />
                        View Details
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleGenerateVoterId(registration)}
                      >
                        <UserCheck className="size-4 mr-2" />
                        Approve & Generate ID
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Approved Registrations List */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Approved Voter Registrations</CardTitle>
            <CardDescription>
              Registered voters with approved applications and generated voter IDs
            </CardDescription>
          </div>
          <Button
            onClick={downloadApprovedAsExcel}
            variant="outline"
            size="sm"
            disabled={approvedRegistrations.length === 0}
          >
            <Download className="size-4 mr-2" />
            Download Excel
          </Button>
        </CardHeader>
        <CardContent>
          {approvedRegistrations.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No approved registrations yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {approvedRegistrations.map((registration) => (
                <div
                  key={registration.id}
                  className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex gap-4 flex-1">
                      <img
                        src={registration.facePhoto}
                        alt={registration.name}
                        className="size-16 rounded-full object-cover border-2 border-green-200"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">{registration.name}</h3>
                          <Badge className="bg-green-100 text-green-800">Approved</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{registration.email}</p>
                        <p className="text-sm text-gray-600">{registration.phone}</p>
                        {registration.generatedVoterId && (
                          <p className="text-sm font-medium text-green-600 mt-2">
                            Voter ID: {registration.generatedVoterId}
                          </p>
                        )}
                        <p className="text-xs text-gray-500 mt-2">
                          Registered: {registration.registrationDate}
                        </p>
                      </div>
                    </div>
                    <div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleViewDetails(registration)}
                      >
                        <Eye className="size-4 mr-2" />
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Registration Details</DialogTitle>
            <DialogDescription>
              Review complete registration information
            </DialogDescription>
          </DialogHeader>
          {selectedRegistration && (
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Face Photo</h4>
                  <img
                    src={selectedRegistration.facePhoto}
                    alt={selectedRegistration.name}
                    className="w-full aspect-square object-cover rounded-lg border"
                  />
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Voter ID Document</h4>
                  <img
                    src={selectedRegistration.voterIdDocument}
                    alt="Voter ID Document"
                    className="w-full aspect-square object-cover rounded-lg border"
                  />
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Name</p>
                  <p className="font-medium">{selectedRegistration.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium">{selectedRegistration.email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Phone</p>
                  <p className="font-medium">{selectedRegistration.phone}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Date of Birth</p>
                  <p className="font-medium">{selectedRegistration.dateOfBirth}</p>
                </div>
                <div className="md:col-span-2">
                  <p className="text-sm text-gray-500">Address</p>
                  <p className="font-medium">{selectedRegistration.address}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    setShowDetails(false);
                    handleGenerateVoterId(selectedRegistration);
                  }}
                  className="flex-1"
                >
                  <UserCheck className="size-4 mr-2" />
                  Approve & Generate ID
                </Button>
                <Button
                  onClick={handleReject}
                  variant="destructive"
                  className="flex-1"
                >
                  <UserX className="size-4 mr-2" />
                  Reject
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Generate Voter ID Dialog */}
      <Dialog open={showGenerateId} onOpenChange={setShowGenerateId}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Generate Voter ID</DialogTitle>
            <DialogDescription>
              Create a unique voter ID for {selectedRegistration?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="voter-id">Voter ID *</Label>
              <Input
                id="voter-id"
                value={generatedVoterId}
                onChange={(e) => setGeneratedVoterId(e.target.value)}
                placeholder="VID-2025-001234"
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="constituency">Constituency *</Label>
              <Input
                id="constituency"
                value={constituency}
                onChange={(e) => setConstituency(e.target.value)}
                placeholder="District 5 - North"
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="polling-station">Polling Station *</Label>
              <Input
                id="polling-station"
                value={pollingStation}
                onChange={(e) => setPollingStation(e.target.value)}
                placeholder="Community Center A"
                className="mt-2"
              />
            </div>
            <Button onClick={handleApproveWithVoterId} className="w-full">
              Generate Voter ID Card
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Voter ID Card Preview & Send Dialog */}
      <Dialog open={showVoterCard} onOpenChange={setShowVoterCard}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Voter ID Card Generated</DialogTitle>
            <DialogDescription>
              Review and send the voter ID card to the applicant
            </DialogDescription>
          </DialogHeader>
          {voterCardData && (
            <div className="space-y-4">
              <VoterIDCard voter={voterCardData} showDownload={false} />
              <div className="grid grid-cols-1 gap-2">
                <Button onClick={handleSendVoterIdToEmail} className="w-full" size="lg">
                  <Send className="size-4 mr-2" />
                  Send Voter ID to {voterCardData.email}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}