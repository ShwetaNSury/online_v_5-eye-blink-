// Registration functionality
let currentStep = 1;
let registrationData = {
    personalInfo: {},
    facePhoto: null,
    idDocument: null
};
let regStream = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeRegistrationForm();
    setupFileUpload();
});

// Multi-step navigation
function goToStep(step) {
    if (step < 1 || step > 4) return;
    
    // Validate current step before moving forward
    if (step > currentStep && !validateCurrentStep()) {
        return;
    }
    
    currentStep = step;
    updateStepUI();
}

// Calculate age from date of birth
function calculateAge(dateOfBirth) {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }

    return age;
}

function validateCurrentStep() {
    if (currentStep === 1) {
        const form = document.getElementById('personalInfoForm');
        if (!form.checkValidity()) {
            form.reportValidity();
            return false;
        }
        
        // Validate age limit (18-100 years)
        const dob = document.getElementById('dob').value;
        const age = calculateAge(dob);
        
        if (age < 18) {
            window.appUtils.showToast('You must be at least 18 years old to register', 'error');
            return false;
        }
        if (age > 100) {
            window.appUtils.showToast('Please enter a valid date of birth (maximum age is 100 years)', 'error');
            return false;
        }
        
        savePersonalInfo();
        return true;
    } else if (currentStep === 2) {
        if (!registrationData.facePhoto) {
            window.appUtils.showToast('Please capture your photo', 'error');
            return false;
        }
        return true;
    } else if (currentStep === 3) {
        if (!registrationData.idDocument) {
            window.appUtils.showToast('Please upload your ID document', 'error');
            return false;
        }
        return true;
    }
    return true;
}

function updateStepUI() {
    // Update step indicators
    document.querySelectorAll('.step').forEach((step, index) => {
        const stepNum = index + 1;
        if (stepNum < currentStep) {
            step.classList.add('completed');
            step.classList.remove('active');
        } else if (stepNum === currentStep) {
            step.classList.add('active');
            step.classList.remove('completed');
        } else {
            step.classList.remove('active', 'completed');
        }
    });
    
    // Show/hide step content
    document.querySelectorAll('.registration-step').forEach((stepContent, index) => {
        if (index + 1 === currentStep) {
            stepContent.classList.add('active');
        } else {
            stepContent.classList.remove('active');
        }
    });
    
    // Update review section if on step 4
    if (currentStep === 4) {
        populateReviewSection();
    }
}

// Step 1: Personal Information
function initializeRegistrationForm() {
    const form = document.getElementById('personalInfoForm');
    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            if (validateCurrentStep()) {
                goToStep(2);
            }
        });
    }
    
    // Terms checkbox
    const termsCheckbox = document.getElementById('termsAccept');
    if (termsCheckbox) {
        termsCheckbox.addEventListener('change', (e) => {
            document.getElementById('submitRegistration').disabled = !e.target.checked;
        });
    }
}

function savePersonalInfo() {
    registrationData.personalInfo = {
        name: document.getElementById('fullName').value,
        email: document.getElementById('regEmail').value,
        password: document.getElementById('regPassword').value,
        phone: document.getElementById('phone').value,
        dateOfBirth: document.getElementById('dob').value,
        address: document.getElementById('address').value
    };
}

// Step 2: Face Capture
function captureRegistrationPhoto() {
    const video = document.getElementById('regVideo');
    const canvas = document.getElementById('regCanvas');
    const capturedPhotoContainer = document.getElementById('regCapturedPhotoContainer');
    const capturedPhoto = document.getElementById('regCapturedPhoto');
    const cameraContainer = document.getElementById('regCameraContainer');
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    
    const photoData = canvas.toDataURL('image/jpeg');
    registrationData.facePhoto = photoData;
    capturedPhoto.src = photoData;
    
    // Show captured photo, hide video
    cameraContainer.style.display = 'none';
    capturedPhotoContainer.style.display = 'block';
    
    // Update buttons
    document.getElementById('regCaptureBtn').style.display = 'none';
    document.getElementById('regRetakeBtn').style.display = 'inline-flex';
    document.getElementById('nextFromStep2').disabled = false;
    
    stopRegStream();
}

function retakeRegistrationPhoto() {
    const cameraContainer = document.getElementById('regCameraContainer');
    const capturedPhotoContainer = document.getElementById('regCapturedPhotoContainer');
    
    cameraContainer.style.display = 'block';
    capturedPhotoContainer.style.display = 'none';
    
    document.getElementById('regCaptureBtn').style.display = 'inline-flex';
    document.getElementById('regRetakeBtn').style.display = 'none';
    document.getElementById('nextFromStep2').disabled = true;
    
    registrationData.facePhoto = null;
    startRegCamera();
}

function useRegSamplePhoto(index) {
    const colors = [
        ['#f59e0b', '#d97706'],
        ['#8b5cf6', '#7c3aed'],
        ['#10b981', '#059669']
    ];
    const labels = ['SAMPLE USER 1', 'SAMPLE USER 2', 'SAMPLE USER 3'];
    
    const photoData = window.appUtils.generateSampleFacePhoto(colors[index - 1][0], colors[index - 1][1], labels[index - 1]);
    registrationData.facePhoto = photoData;
    
    const capturedPhoto = document.getElementById('regCapturedPhoto');
    const capturedPhotoContainer = document.getElementById('regCapturedPhotoContainer');
    const cameraContainer = document.getElementById('regCameraContainer');
    
    capturedPhoto.src = photoData;
    cameraContainer.style.display = 'none';
    capturedPhotoContainer.style.display = 'block';
    
    document.getElementById('regCaptureBtn').style.display = 'none';
    document.getElementById('regRetakeBtn').style.display = 'inline-flex';
    document.getElementById('nextFromStep2').disabled = false;
    
    stopRegStream();
}

function startRegCamera() {
    const video = document.getElementById('regVideo');
    
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            regStream = stream;
            video.srcObject = stream;
        })
        .catch(err => {
            console.error('Error accessing camera:', err);
            window.appUtils.showToast('Camera access denied. You can use sample photo for testing.', 'warning');
        });
}

function stopRegStream() {
    if (regStream) {
        regStream.getTracks().forEach(track => track.stop());
        regStream = null;
    }
}

// Start camera when entering step 2
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        const step2 = document.getElementById('step2');
        if (step2 && step2.classList.contains('active')) {
            const video = document.getElementById('regVideo');
            if (video && !video.srcObject) {
                startRegCamera();
            }
        }
    });
});

observer.observe(document.body, {
    subtree: true,
    attributes: true,
    attributeFilter: ['class']
});

// Step 3: ID Document Upload
function setupFileUpload() {
    const fileInput = document.getElementById('idFileInput');
    const uploadArea = document.getElementById('uploadArea');
    
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelect);
    }
    
    if (uploadArea) {
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#2563eb';
            uploadArea.style.backgroundColor = 'rgba(37, 99, 235, 0.05)';
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.style.borderColor = '';
            uploadArea.style.backgroundColor = '';
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '';
            uploadArea.style.backgroundColor = '';
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFile(files[0]);
            }
        });
    }
}

function handleFileSelect(e) {
    const files = e.target.files;
    if (files.length > 0) {
        handleFile(files[0]);
    }
}

function handleFile(file) {
    if (!file.type.startsWith('image/')) {
        window.appUtils.showToast('Please upload an image file', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
        registrationData.idDocument = e.target.result;
        displayUploadedID(e.target.result);
    };
    reader.readAsDataURL(file);
}

function displayUploadedID(dataUrl) {
    const uploadArea = document.getElementById('uploadArea');
    const uploadedPreview = document.getElementById('uploadedPreview');
    const idPreview = document.getElementById('idPreview');
    
    idPreview.src = dataUrl;
    uploadArea.style.display = 'none';
    uploadedPreview.style.display = 'block';
    
    document.getElementById('nextFromStep3').disabled = false;
}

function removeIdDocument() {
    const uploadArea = document.getElementById('uploadArea');
    const uploadedPreview = document.getElementById('uploadedPreview');
    
    registrationData.idDocument = null;
    uploadArea.style.display = 'flex';
    uploadedPreview.style.display = 'none';
    document.getElementById('nextFromStep3').disabled = true;
    document.getElementById('idFileInput').value = '';
}

function useSampleID() {
    const idDocument = window.appUtils.generateSampleIDDocument();
    registrationData.idDocument = idDocument;
    displayUploadedID(idDocument);
}

// Step 4: Review
function populateReviewSection() {
    const { personalInfo, facePhoto, idDocument } = registrationData;
    
    document.getElementById('reviewName').textContent = personalInfo.name;
    document.getElementById('reviewEmail').textContent = personalInfo.email;
    document.getElementById('reviewPhone').textContent = personalInfo.phone;
    document.getElementById('reviewDob').textContent = new Date(personalInfo.dateOfBirth).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    document.getElementById('reviewAddress').textContent = personalInfo.address;
    
    document.getElementById('reviewFacePhoto').src = facePhoto;
    document.getElementById('reviewIdDocument').src = idDocument;
}

function submitRegistration() {
    const { personalInfo, facePhoto, idDocument } = registrationData;
    
    // Get current pending registrations
    const pendingRegistrations = window.appUtils.getPendingRegistrations();
    
    // Create new registration
    const newRegistration = {
        id: Date.now().toString(),
        name: personalInfo.name,
        email: personalInfo.email,
        password: personalInfo.password,
        phone: personalInfo.phone,
        dateOfBirth: personalInfo.dateOfBirth,
        address: personalInfo.address,
        facePhoto: facePhoto,
        voterIdDocument: idDocument,
        status: 'pending',
        registrationDate: new Date().toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        })
    };
    
    // Add to pending registrations
    pendingRegistrations.push(newRegistration);
    window.appUtils.setPendingRegistrations(pendingRegistrations);
    
    // Show success message
    document.querySelectorAll('.registration-step').forEach(step => step.style.display = 'none');
    document.getElementById('successStep').style.display = 'block';
    
    // Reset form data
    registrationData = {
        personalInfo: {},
        facePhoto: null,
        idDocument: null
    };
}

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    stopRegStream();
});
