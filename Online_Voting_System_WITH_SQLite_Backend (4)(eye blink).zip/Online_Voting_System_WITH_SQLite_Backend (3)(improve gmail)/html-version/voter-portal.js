// Voter Portal functionality
let selectedElectionForVoting = null;
let selectedCandidateId = null;

// Render elections
function renderElections() {
    const elections = window.appUtils.getElections();
    const searchQuery = document.getElementById('searchInput')?.value.toLowerCase() || '';
    
    // Filter elections by search query
    const filteredElections = elections.filter(election => {
        return election.title.toLowerCase().includes(searchQuery) ||
               election.description.toLowerCase().includes(searchQuery);
    });
    
    // Categorize elections
    const activeElections = filteredElections.filter(e => window.appUtils.getElectionStatus(e) === 'active');
    const upcomingElections = filteredElections.filter(e => window.appUtils.getElectionStatus(e) === 'upcoming');
    const closedElections = filteredElections.filter(e => window.appUtils.getElectionStatus(e) === 'closed');
    
    // Update counts
    updateBadge('activeCount', activeElections.length);
    updateBadge('upcomingCount', upcomingElections.length);
    updateBadge('resultsCount', closedElections.length);
    
    // Update stats
    updateStats(elections);
    
    // Render each category
    renderElectionList('activeElections', activeElections, true);
    renderElectionList('upcomingElections', upcomingElections, false);
    renderElectionList('resultsElections', closedElections, false);
}

function updateBadge(id, count) {
    const badge = document.getElementById(id);
    if (badge) {
        badge.textContent = count;
    }
}

function updateStats(elections) {
    const totalVoters = 5000;
    const activeCount = elections.filter(e => window.appUtils.getElectionStatus(e) === 'active').length;
    
    const totalVotersEl = document.getElementById('totalVoters');
    const activeElectionsEl = document.getElementById('activeElections');
    
    if (totalVotersEl) totalVotersEl.textContent = totalVoters.toLocaleString();
    if (activeElectionsEl) activeElectionsEl.textContent = activeCount;
}

function renderElectionList(containerId, elections, canVote) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    if (elections.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: #6b7280;">
                <p>No elections available</p>
            </div>
        `;
        return;
    }
    
    const votedElections = window.appUtils.getVotedElections();
    const currentUser = window.appUtils.getCurrentUser();
    
    container.innerHTML = elections.map(election => {
        const hasVoted = votedElections[election.id];
        const statusBadge = getStatusBadge(election);
        const turnout = window.appUtils.calculatePercentage(election.totalVotes, election.eligibleVoters);
        
        return `
            <div class="election-card">
                <div class="election-card-header">
                    <h3>${election.title}</h3>
                    <p>${election.description}</p>
                </div>
                <div class="election-card-meta">
                    ${statusBadge}
                    <span><i class="fas fa-calendar"></i> ${window.appUtils.formatDate(election.startDate)} - ${window.appUtils.formatDate(election.endDate)}</span>
                </div>
                <div class="election-card-stats">
                    <div class="stat-item">
                        <strong>${election.totalVotes}</strong>
                        <span>Total Votes</span>
                    </div>
                    <div class="stat-item">
                        <strong>${election.candidates.length}</strong>
                        <span>Candidates</span>
                    </div>
                    <div class="stat-item">
                        <strong>${turnout}%</strong>
                        <span>Turnout</span>
                    </div>
                </div>
                <div class="election-card-actions">
                    ${canVote && !hasVoted ? `
                        <button class="btn btn-primary" onclick="openVotingModal('${election.id}')">
                            <i class="fas fa-vote-yea"></i> Vote Now
                        </button>
                    ` : ''}
                    ${hasVoted ? `
                        <button class="btn btn-success" disabled>
                            <i class="fas fa-check"></i> Voted
                        </button>
                    ` : ''}
                    <button class="btn btn-secondary" onclick="viewResults('${election.id}')">
                        <i class="fas fa-chart-bar"></i> Results
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function getStatusBadge(election) {
    const status = window.appUtils.getElectionStatus(election);
    const colors = {
        active: 'success',
        upcoming: 'warning',
        closed: 'secondary'
    };
    const labels = {
        active: 'Active',
        upcoming: 'Upcoming',
        closed: 'Closed'
    };
    
    return `<span class="badge" style="background-color: var(--${colors[status]}-color);">${labels[status]}</span>`;
}

// Voting Modal
function openVotingModal(electionId) {
    const currentUser = window.appUtils.getCurrentUser();
    
    if (!currentUser) {
        window.appUtils.showToast('Please login to vote', 'error');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1000);
        return;
    }
    
    const elections = window.appUtils.getElections();
    selectedElectionForVoting = elections.find(e => e.id === electionId);
    
    if (!selectedElectionForVoting) return;
    
    const modal = document.getElementById('votingModal');
    const modalTitle = document.getElementById('voteModalTitle');
    const modalBody = document.getElementById('voteModalBody');
    
    modalTitle.textContent = selectedElectionForVoting.title;
    
    modalBody.innerHTML = `
        <p style="margin-bottom: 1.5rem; color: #6b7280;">Select your preferred candidate:</p>
        <div class="candidates-list">
            ${selectedElectionForVoting.candidates.map(candidate => `
                <div class="candidate-option" onclick="selectCandidate('${candidate.id}')">
                    <div class="candidate-radio"></div>
                    <div class="candidate-info">
                        <h4>${candidate.name}</h4>
                        <p>${candidate.party}</p>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
    
    selectedCandidateId = null;
    document.getElementById('submitVoteBtn').disabled = true;
    
    modal.classList.add('active');
}

function closeVotingModal() {
    const modal = document.getElementById('votingModal');
    modal.classList.remove('active');
    selectedElectionForVoting = null;
    selectedCandidateId = null;
}

function selectCandidate(candidateId) {
    selectedCandidateId = candidateId;
    
    // Update UI
    document.querySelectorAll('.candidate-option').forEach(option => {
        option.classList.remove('selected');
    });
    event.target.closest('.candidate-option').classList.add('selected');
    
    document.getElementById('submitVoteBtn').disabled = false;
}

function submitVote() {
    if (!selectedElectionForVoting || !selectedCandidateId) return;
    
    const currentUser = window.appUtils.getCurrentUser();
    if (!currentUser) {
        window.appUtils.showToast('Please login to vote', 'error');
        return;
    }
    
    // Update election with new vote
    const elections = window.appUtils.getElections();
    const updatedElections = elections.map(election => {
        if (election.id === selectedElectionForVoting.id) {
            return {
                ...election,
                candidates: election.candidates.map(candidate => 
                    candidate.id === selectedCandidateId
                        ? { ...candidate, votes: candidate.votes + 1 }
                        : candidate
                ),
                totalVotes: election.totalVotes + 1
            };
        }
        return election;
    });
    
    window.appUtils.setElections(updatedElections);
    
    // Mark as voted
    const votedElections = window.appUtils.getVotedElections();
    votedElections[selectedElectionForVoting.id] = selectedCandidateId;
    window.appUtils.setVotedElections(votedElections);
    
    window.appUtils.showToast('Your vote has been recorded successfully!', 'success');
    
    closeVotingModal();
    renderElections();
}

// View Results
function viewResults(electionId) {
    window.location.href = `results.html?id=${electionId}`;
}

// Search functionality
function setupSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            renderElections();
        });
    }
}

// Close modal when clicking outside
window.addEventListener('click', (event) => {
    const modal = document.getElementById('votingModal');
    if (event.target === modal) {
        closeVotingModal();
    }
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    renderElections();
    setupSearch();
});
