#!/usr/bin/env node
/**
 * Quick Diagnostic Script
 * Run this to see if your email configuration is loaded
 */

import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('📋 VOTER ID EMAIL CONFIGURATION DIAGNOSTIC\n');

// Check .env file
const envPath = path.join(__dirname, '.env');
console.log('1️⃣ Checking .env file...');
if (fs.existsSync(envPath)) {
  console.log('   ✓ .env file found at:', envPath);
  
  // Read and display .env content (masked)
  const envContent = fs.readFileSync(envPath, 'utf-8');
  const lines = envContent.split('\n');
  console.log('\n   File contents:');
  lines.forEach(line => {
    if (line.trim() && !line.startsWith('#')) {
      const [key, value] = line.split('=');
      if (key) {
        const displayValue = key.includes('PASS') 
          ? '*'.repeat(Math.max(3, value.length - 4)) 
          : value.substring(0, 10);
        console.log(`   - ${key}=${displayValue}${value.length > 10 ? '...' : ''}`);
      }
    }
  });
} else {
  console.log('   ✗ .env file NOT found!');
  console.log('   📍 Expected location:', envPath);
}

// Load .env
dotenv.config();

// Check environment variables
console.log('\n2️⃣ Checking loaded environment variables...');
const requiredVars = ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS', 'FROM_EMAIL'];
let allSet = true;

requiredVars.forEach(varName => {
  const value = process.env[varName];
  if (value) {
    const display = varName.includes('PASS') 
      ? value.substring(0, 3) + '***' 
      : value;
    console.log(`   ✓ ${varName} = ${display}`);
  } else {
    console.log(`   ✗ ${varName} = NOT SET`);
    allSet = false;
  }
});

console.log(`\n3️⃣ Overall Status: ${allSet ? '✅ All configured' : '❌ Missing configuration'}`);

if (!allSet) {
  console.log('\n⚠️ Solution:');
  console.log('1. Edit backend/.env file');
  console.log('2. Add your Gmail SMTP credentials:');
  console.log(`
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-16-char-app-password
FROM_EMAIL=your-email@gmail.com
`);
  console.log('3. Save the file');
  console.log('4. Restart the backend server');
}

console.log('\n💡 Next steps:');
console.log('1. Run backend: npm run start');
console.log('2. Test email config: npm run test-email');
console.log('3. Or check via API: curl http://localhost:5000/api/email-config-check');
