# Email Setup Guide - Voter ID PDF Sending

## Prerequisites

Make sure Node.js and npm are installed on your system.

## Step 1: Install Dependencies

Navigate to the backend folder and install all required packages:

```bash
cd backend
npm install
```

This will install:
- **nodemailer** - For sending emails
- **qrcode** - For QR code generation
- **pdfkit** - For PDF generation
- **express** - Web server
- **cors** - Cross-origin support
- **sqlite3** - Database

## Step 2: Configure Gmail SMTP

### For Gmail Users:

1. **Enable 2-Factor Authentication** (if not already enabled):
   - Go to https://myaccount.google.com/security
   - Click "2-Step Verification" and follow the prompts

2. **Generate an App Password**:
   - Go to https://myaccount.google.com/apppasswords
   - Select "Mail" and "Windows Computer"
   - Google will generate a 16-character password
   - Copy this password

3. **Update the `.env` file**:
   - Open `backend/.env`
   - Replace `your-email@gmail.com` with your actual Gmail address
   - Replace `your-app-specific-password` with the 16-character password from step 2
   - **Important**: Remove any spaces from the password if present

Example:
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=myemail@gmail.com
SMTP_PASS=abcdefghijklmnop
FROM_EMAIL=myemail@gmail.com
```

## Step 3: Start the Backend Server

```bash
npm start
```

You should see: `Backend running on http://localhost:5000`

## Step 4: Send a Test Voter ID

Use a tool like **Postman** or **curl** to test:

### Using Postman:
1. Create a POST request to: `http://localhost:5000/api/send-voter-id`
2. Set header: `Content-Type: application/json`
3. Set body (JSON):

```json
{
  "voter": {
    "voterId": "VID-2025-001234",
    "name": "John Doe",
    "email": "recipient@gmail.com",
    "dateOfBirth": "1990-05-15",
    "address": "123 Main Street, City",
    "constituency": "District 5 - North",
    "pollingStation": "Community Center A",
    "registrationDate": "2025-02-11",
    "photo": "data:image/jpeg;base64,/9j/4AAQSkZJRgABA... (base64 encoded image or leave empty)"
  }
}
```

### Using curl:
```bash
curl -X POST http://localhost:5000/api/send-voter-id \
  -H "Content-Type: application/json" \
  -d '{
    "voter": {
      "voterId": "VID-2025-001234",
      "name": "John Doe",
      "email": "recipient@gmail.com",
      "dateOfBirth": "1990-05-15",
      "address": "123 Main Street, City",
      "constituency": "District 5 - North",
      "pollingStation": "Community Center A",
      "registrationDate": "2025-02-11"
    }
  }'
```

## Step 5: Check the Response

**Success Response:**
```json
{
  "success": true,
  "message": "Voter ID sent successfully to recipient@gmail.com",
  "messageId": "<message-id@gmail.com>"
}
```

**Error Response:**
Check the backend console for detailed error messages.

## Troubleshooting

### "SMTP not configured" Error
- Make sure `.env` file exists in the backend folder
- Verify all required variables are set: `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS`, `FROM_EMAIL`
- Restart the backend server after updating `.env`

### "SMTP verification failed" Error
- Check if you used the correct App Password (not your regular Gmail password)
- Make sure 2-Factor Authentication is enabled on your Gmail account
- Verify the email address is correct
- Check your internet connection

### Email Not Received
- Check the spam/junk folder in Gmail
- Check the backend console logs for any errors
- Verify the recipient email address is correct
- Make sure your Gmail account has IMAP access enabled

### "Failed to send email" Error
- Verify SMTP credentials are correct
- Check if backend server has internet connection
- Review server console logs for detailed error message

## Email Content

When the PDF is sent successfully, the recipient will receive:
- **Professional HTML formatted email** with voter information
- **PDF attachment** with the voter ID card
- **QR code** for verification
- **Security notices** about protecting their voter information

## Important Security Notes

⚠️ **Never commit `.env` file to version control**
- Add `.env` to `.gitignore` to prevent accidental exposure of credentials
- The `.env` file contains sensitive information

🔒 **Protect your App Password**
- Don't share your Gmail App Password
- Use different app passwords for different applications
- Revoke app passwords in Google Account if they're compromised

## Additional Email Providers

If you want to use a different email provider instead of Gmail:

### Outlook:
```
SMTP_HOST=smtp-mail.outlook.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@outlook.com
SMTP_PASS=your-password
FROM_EMAIL=your-email@outlook.com
```

### Generic SMTP Server:
```
SMTP_HOST=smtp.your-provider.com
SMTP_PORT=587
SMTP_SECURE=true
SMTP_USER=your-username
SMTP_PASS=your-password
FROM_EMAIL=noreply@yourdomain.com
```

## Need Help?

If you encounter issues:
1. Check the backend console for detailed error messages
2. Verify all configuration steps above
3. Ensure internet connection is working
4. Try with a test email address first
