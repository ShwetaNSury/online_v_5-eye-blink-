#!/usr/bin/env node
/**
 * Test Email Configuration Script
 * This script tests if your Gmail SMTP configuration is working correctly
 */

import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables
dotenv.config();

console.log('='.repeat(60));
console.log('VOTER ID EMAIL CONFIGURATION TEST');
console.log('='.repeat(60));

// Check if .env file exists
const envPath = path.join(__dirname, '.env');
if (!fs.existsSync(envPath)) {
  console.error('\n❌ ERROR: .env file not found!');
  console.log('Please create a .env file with the following content:');
  console.log(`
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-specific-password
FROM_EMAIL=your-email@gmail.com
  `);
  process.exit(1);
}

console.log('\n✓ .env file found');

// Check environment variables
const requiredVars = ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS', 'FROM_EMAIL'];
const missingVars = requiredVars.filter(v => !process.env[v]);

if (missingVars.length > 0) {
  console.error('\n❌ Missing environment variables:', missingVars.join(', '));
  process.exit(1);
}

console.log('✓ All required environment variables are set');

// Display configuration (masked)
console.log('\n📧 SMTP Configuration:');
console.log(`  Host: ${process.env.SMTP_HOST}`);
console.log(`  Port: ${process.env.SMTP_PORT || 587}`);
console.log(`  User: ${process.env.SMTP_USER}`);
console.log(`  Pass: ${process.env.SMTP_PASS.substring(0, 3)}${'*'.repeat(Math.max(0, process.env.SMTP_PASS.length - 6))}${process.env.SMTP_PASS.substring(Math.max(0, process.env.SMTP_PASS.length - 3))}`);
console.log(`  From: ${process.env.FROM_EMAIL}`);

// Create transporter
console.log('\n🔄 Testing SMTP connection...');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 587,
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  },
  connectionTimeout: 10000,
  socketTimeout: 15000,
  tls: {
    rejectUnauthorized: false
  }
});

// Verify connection
transporter.verify((error, success) => {
  if (error) {
    console.warn('\n⚠️ SMTP verification warning (attempting to send anyway):');
    console.warn('Error:', error.message);
    
    // Continue with sending email despite verification warning
    sendTestEmail();
  } else {
    console.log('✓ SMTP connection verified successfully!');
    sendTestEmail();
  }
});

function sendTestEmail() {
  console.log('📨 Sending test email...');
  
  const testEmail = process.env.SMTP_USER;
  const mailOptions = {
    from: process.env.FROM_EMAIL,
    to: testEmail,
      subject: '✅ Voter ID System - Email Configuration Test',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(to right, #1e40af, #1e3a8a); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
            <h1 style="margin: 0;">✅ Email Configuration Test Successful</h1>
          </div>
          <div style="padding: 20px; background-color: #f5f5f5; border-radius: 0 0 8px 8px;">
            <p style="color: #333; font-size: 16px;">Great news! Your SMTP configuration is working correctly.</p>
            
            <div style="background-color: white; padding: 15px; border-radius: 4px; margin: 20px 0; border-left: 4px solid #10b981;">
              <p style="margin: 0; color: #333;">
                <strong>Status:</strong> ✅ Ready to send Voter ID emails
              </p>
            </div>

            <h3 style="color: #1e40af; margin-top: 20px;">Test Details:</h3>
            <ul style="color: #666; line-height: 1.8;">
              <li><strong>Test Recipient:</strong> ${testEmail}</li>
              <li><strong>SMTP Host:</strong> ${process.env.SMTP_HOST}</li>
              <li><strong>Date:</strong> ${new Date().toLocaleString()}</li>
            </ul>

            <h3 style="color: #1e40af;">Next Steps:</h3>
            <ol style="color: #666; line-height: 1.8;">
              <li>Start the backend server: <code>npm start</code></li>
              <li>Use the API endpoint to send Voter IDs</li>
              <li>Check your inbox for test emails</li>
            </ol>

            <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; border-radius: 4px; margin-top: 20px;">
              <strong style="color: #92400e;">Note:</strong> This is an automated test email. If you received this, your email configuration is working correctly.
            </div>
          </div>
        </div>
      `,
      text: 'Your email configuration is working correctly!'
    };

    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        console.error('\n❌ Failed to send test email:');
        console.error('Error:', err.message);
        process.exit(1);
      } else {
        console.log('✓ Test email sent successfully!');
        console.log('\n' + '='.repeat(60));
        console.log('✅ ALL TESTS PASSED - SYSTEM READY');
        console.log('='.repeat(60));
        console.log(`\n📧 Test email sent to: ${testEmail}`);
        console.log('Message ID:', info.messageId);
        console.log('\nYour system is ready to send Voter ID PDFs via email!');
        console.log('\nTo send voter IDs, use the API endpoint:');
        console.log('POST http://localhost:5000/api/send-voter-id');
        console.log('\nRefer to SETUP_GUIDE.md for complete instructions.');
        process.exit(0);
      }
    });
}
