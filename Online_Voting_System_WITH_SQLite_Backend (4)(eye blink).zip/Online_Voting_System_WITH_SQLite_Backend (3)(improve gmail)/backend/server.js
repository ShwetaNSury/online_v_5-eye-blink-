import express from "express";
import cors from "cors";
import sqlite3 from "sqlite3";
import PDFDocument from "pdfkit";
import nodemailer from "nodemailer";
import QRCode from "qrcode";
import puppeteer from 'puppeteer';
import fs from 'fs';
import path from 'path';
import os from 'os';
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const db = new sqlite3.Database("./voting.db", (err) => {
  if (err) console.error(err.message);
  else console.log("Connected to SQLite database");
});

db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, hasVoted INTEGER DEFAULT 0)");
  db.run("CREATE TABLE IF NOT EXISTS candidates (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, party TEXT, votes INTEGER DEFAULT 0)");
  db.run("INSERT INTO candidates (name, party) SELECT 'Candidate A','Party X' WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name='Candidate A')");
  db.run("INSERT INTO candidates (name, party) SELECT 'Candidate B','Party Y' WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name='Candidate B')");
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: '✅ ElectionHub Voting Backend is Running',
    status: 'operational',
    endpoints: {
      health: '/api/health',
      emailConfig: '/api/email-config-check',
      register: 'POST /api/register',
      candidates: 'GET /api/candidates',
      vote: 'POST /api/vote/:id',
      results: 'GET /api/results',
      sendVoterId: 'POST /api/send-voter-id'
    }
  });
});

// Register
app.post("/api/register", (req, res) => {
  const { name, email } = req.body;
  db.run("INSERT INTO users (name,email) VALUES (?,?)",[name,email], function(err){
    if(err) return res.status(500).json({error:err.message});
    res.json({id:this.lastID, name, email});
  });
});

// Get Candidates
app.get("/api/candidates", (req,res)=>{
  db.all("SELECT * FROM candidates",[],(err,rows)=>{
    if(err) return res.status(500).json({error:err.message});
    res.json(rows);
  });
});

// Vote (one vote per user not enforced here - simple version)
app.post("/api/vote/:id",(req,res)=>{
  db.run("UPDATE candidates SET votes=votes+1 WHERE id=?",[req.params.id], function(err){
    if(err) return res.status(500).json({error:err.message});
    res.json({message:"Vote counted"});
  });
});

// Results
app.get("/api/results",(req,res)=>{
  db.all("SELECT * FROM candidates",[],(err,rows)=>{
    if(err) return res.status(500).json({error:err.message});
    res.json(rows);
  });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'Backend server is running',
    timestamp: new Date().toISOString()
  });
});

// Diagnostic endpoint to check email configuration
app.get('/api/email-config-check', (req, res) => {
  const smtpHost = process.env.SMTP_HOST;
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const fromEmail = process.env.FROM_EMAIL;

  console.log('[/api/email-config-check] Configuration check requested');

  const config = {
    SMTP_HOST: smtpHost ? '✓ Set' : '✗ Missing',
    SMTP_PORT: process.env.SMTP_PORT || '587',
    SMTP_SECURE: process.env.SMTP_SECURE || 'false',
    SMTP_USER: smtpUser ? smtpUser.substring(0, 5) + '***' : '✗ Missing',
    SMTP_PASS: smtpPass ? '[' + smtpPass.length + ' chars]' : '✗ Missing',
    FROM_EMAIL: fromEmail || smtpUser,
    ALL_CONFIGURED: !!(smtpHost && smtpUser && smtpPass)
  };

  res.json(config);
});

// Helper function to generate QR code buffer
async function generateQRCode(data) {
  try {
    return await QRCode.toBuffer(JSON.stringify(data), {
      errorCorrectionLevel: 'H',
      type: 'image/png',
      quality: 0.95,
      margin: 1,
      width: 250,
      color: { dark: '#000000', light: '#FFFFFF' }
    });
  } catch (err) {
    console.error('QR Code generation error:', err);
    throw new Error('Failed to generate QR code');
  }
}

// Helper function to generate PDF with all voter details
async function generateVoterIDPDF(voter, qrCodeBuffer) {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: 'A4', margin: 40, bufferPages: true });
      const chunks = [];

      doc.on('data', (chunk) => chunks.push(chunk));
      doc.on('error', (err) => reject(err));
      doc.on('end', () => resolve(Buffer.concat(chunks)));

      // Get current date
      const issueDate = new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      });

      // Header with colored background
      doc.rect(0, 0, doc.page.width, 80).fill('#1e40af');
      doc.fillColor('#ffffff');
      doc.fontSize(28).font('Helvetica-Bold').text('VOTER IDENTIFICATION CARD', 50, 20);
      doc.fontSize(11).font('Helvetica').text('ElectionHub Digital Platform', 50, 55);

      doc.moveTo(50, 90).lineTo(doc.page.width - 50, 90).stroke('#1e40af');

      // Main content - two column layout
      let yPosition = 120;

      // Photo section (left side)
      const photoX = 50;
      const photoY = yPosition;
      const photoSize = 140;

      if (voter.photo && typeof voter.photo === 'string' && voter.photo.startsWith('data:')) {
        try {
          const base64Data = voter.photo.split(',')[1];
          const photoBuffer = Buffer.from(base64Data, 'base64');
          doc.image(photoBuffer, photoX, photoY, { width: photoSize, height: photoSize });
        } catch (e) {
          // Draw placeholder if photo can't be embedded
          doc.rect(photoX, photoY, photoSize, photoSize).stroke('#cccccc');
          doc.fontSize(10).fillColor('#666666').text('Photo', photoX + 35, photoY + 65);
        }
      } else {
        // Draw placeholder
        doc.rect(photoX, photoY, photoSize, photoSize).stroke('#cccccc');
        doc.fontSize(10).fillColor('#666666').text('Photo', photoX + 35, photoY + 65);
      }

      // Details section (right side)
      const detailsX = photoX + photoSize + 30;
      const rightColumnWidth = doc.page.width - detailsX - 50;

      doc.fillColor('#000000');

      // Voter ID - prominently displayed
      doc.fontSize(11).font('Helvetica-Bold').text('VOTER ID:', detailsX, photoY);
      doc.fontSize(18).font('Helvetica-Bold').text(voter.voterId, detailsX, photoY + 25);

      yPosition = photoY + 70;

      // Details in two columns
      const col1X = detailsX;
      const col2X = detailsX + rightColumnWidth / 2;
      let col1Y = yPosition;
      let col2Y = yPosition;

      // Left column
      const detailsCol1 = [
        { label: 'Name:', value: voter.name },
        { label: 'Email:', value: voter.email || 'N/A' },
        { label: 'DOB:', value: voter.dateOfBirth || 'N/A' }
      ];

      doc.fontSize(10).font('Helvetica-Bold');
      detailsCol1.forEach(detail => {
        doc.fillColor('#1e40af').text(detail.label, col1X, col1Y);
        doc.fillColor('#000000').font('Helvetica').text(detail.value, col1X + 60, col1Y, { width: 150 });
        col1Y += 35;
      });

      // Right column
      const detailsCol2 = [
        { label: 'Constituency:', value: voter.constituency || 'N/A' },
        { label: 'Polling Station:', value: voter.pollingStation || 'N/A' },
        { label: 'Register Date:', value: voter.registrationDate || 'N/A' }
      ];

      doc.fontSize(10).font('Helvetica-Bold');
      detailsCol2.forEach(detail => {
        doc.fillColor('#1e40af').text(detail.label, col2X, col2Y);
        doc.fillColor('#000000').font('Helvetica').text(detail.value, col2X + 80, col2Y, { width: rightColumnWidth / 2 - 80 });
        col2Y += 35;
      });

      // Address
      const addressY = Math.max(col1Y, col2Y) + 10;
      doc.fontSize(10).font('Helvetica-Bold').fillColor('#1e40af').text('Address:', 50, addressY);
      doc.font('Helvetica').fillColor('#000000').text(voter.address || 'N/A', 50, addressY + 18, { width: doc.page.width - 100 });

      // QR Code section
      const qrY = addressY + 80;
      doc.fontSize(11).font('Helvetica-Bold').fillColor('#1e40af').text('Verification QR Code:', 50, qrY);
      
      if (qrCodeBuffer) {
        doc.image(qrCodeBuffer, doc.page.width / 2 - 70, qrY + 25, { width: 140, height: 140 });
      }

      // Footer
      const footerY = doc.page.height - 60;
      doc.moveTo(50, footerY).lineTo(doc.page.width - 50, footerY).stroke('#1e40af');
      
      doc.fontSize(9).font('Helvetica').fillColor('#666666').text(
        'This is an official digital voter identification card. Keep it secure and present during voting.',
        50,
        footerY + 10,
        { align: 'center', width: doc.page.width - 100 }
      );

      doc.fontSize(8).fillColor('#999999').text(
        `Issued: ${issueDate} | Valid for this election cycle`,
        50,
        footerY + 35,
        { align: 'center', width: doc.page.width - 100 }
      );

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

// Helper function to generate HTML email template
function generateEmailHTML(voter, voterIdPNG) {
  const currentDate = new Date().toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const imageBase64 = voterIdPNG ? voterIdPNG.toString('base64') : '';

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden; }
        .header { background: linear-gradient(to right, #1e40af, #1e3a8a); color: white; padding: 30px; text-align: center; }
        .header h1 { margin: 0; font-size: 28px; font-weight: bold; }
        .header p { margin: 5px 0 0 0; font-size: 14px; opacity: 0.9; }
        .content { padding: 30px; }
        .greeting { font-size: 16px; color: #333; margin-bottom: 20px; }
        .highlight-box { background-color: #f0f7ff; border-left: 4px solid #1e40af; padding: 15px; margin: 20px 0; border-radius: 4px; }
        .highlight-box strong { color: #1e40af; }
        .voter-id-display { font-size: 24px; font-weight: bold; color: #1e40af; margin: 10px 0; font-family: monospace; letter-spacing: 2px; }
        .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
        .detail-item { background-color: #f9fafb; padding: 12px; border-radius: 4px; }
        .detail-label { font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; }
        .detail-value { font-size: 14px; color: #333; margin-top: 5px; font-weight: 500; }
        .card-image { text-align: center; margin: 30px 0; }
        .card-image img { max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .divider { border-top: 1px solid #e5e7eb; margin: 20px 0; }
        .instructions { background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; border-radius: 4px; margin: 20px 0; }
        .instructions h3 { margin-top: 0; color: #92400e; }
        .instructions ul { margin: 10px 0; padding-left: 20px; }
        .instructions li { margin: 5px 0; color: #78350f; }
        .footer { background-color: #f9fafb; padding: 20px; text-align: center; border-top: 1px solid #e5e7eb; font-size: 12px; color: #666; }
        .footer a { color: #1e40af; text-decoration: none; }
        .security-notice { background-color: #fee2e2; border-left: 4px solid #dc2626; padding: 15px; border-radius: 4px; margin: 20px 0; font-size: 13px; color: #7f1d1d; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🎫 Voter ID Card</h1>
          <p>ElectionHub Digital Platform</p>
        </div>

        <div class="content">
          <p class="greeting">Hello <strong>${voter.name}</strong>,</p>

          <p>Your voter identification card has been successfully generated and is ready for use. This card is your official digital identity for voting purposes.</p>

          <div class="highlight-box">
            <strong>Your Voter ID:</strong>
            <div class="voter-id-display">${voter.voterId}</div>
          </div>

          <h3 style="color: #1e40af; margin-top: 25px;">Voter Information</h3>
          <div class="details-grid">
            <div class="detail-item">
              <div class="detail-label">Email Address</div>
              <div class="detail-value">${voter.email || 'N/A'}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">Date of Birth</div>
              <div class="detail-value">${voter.dateOfBirth || 'N/A'}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">Constituency</div>
              <div class="detail-value">${voter.constituency || 'N/A'}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">Polling Station</div>
              <div class="detail-value">${voter.pollingStation || 'N/A'}</div>
            </div>
          </div>

          ${imageBase64 ? `
          <div class="card-image">
            <h3 style="color: #1e40af;">Your Digital Voter Card</h3>
            <img src="data:image/png;base64,${imageBase64}" alt="Voter ID Card">
          </div>
          ` : ''}

          <div class="divider"></div>

          <div class="instructions">
            <h3>📋 How to Use Your Voter ID</h3>
            <ul>
              <li>Keep your voter ID safe and secure</li>
              <li>Present this card during the voting process</li>
              <li>The QR code can be used for quick verification</li>
              <li>Do not share your voter ID with unauthorized personnel</li>
              <li>Contact our support team if you have any questions</li>
            </ul>
          </div>

          <div class="security-notice">
            🔒 <strong>Important Security Notice:</strong> This is a confidential document. Do not forward this email to unauthorized parties. Your voter information is protected and should be treated as sensitive data.
          </div>

          <p style="color: #666; font-size: 13px; line-height: 1.6;">
            If you did not request this voter ID card, or if you believe there's an issue with your registration, please contact our election commission immediately at <strong>support@electionhub.local</strong>.
          </p>
        </div>

        <div class="footer">
          <p>
            <strong>ElectionHub</strong> - Official Digital Voting Platform<br>
            Issued: ${currentDate}<br>
            <a href="https://electionhub.local">www.electionhub.local</a>
          </p>
          <p style="margin-top: 15px; border-top: 1px solid #d1d5db; padding-top: 15px;">
            © 2025 Election Commission. All rights reserved.
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
}

// Helper function to generate voter card image
async function generateVoterCardImage(voter, qrCodeBuffer) {
  // For now, return null - you can implement canvas-based image generation if needed
  // This placeholder allows the email to work without image generation
  return null;
}

// Render a full HTML representation of the voter card matching the UI
function renderVoterCardHTML(voter, qrDataUrl) {
  const photoSrc = voter.photo && voter.photo.startsWith('data:') ? voter.photo : '';
  const issueDate = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  return `<!doctype html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
      body { font-family: Inter, system-ui, -apple-system, 'Helvetica Neue', Arial; margin:0; padding:0; background:#f3f4f6; }
      .card { width: 800px; height: 1100px; margin: 30px auto; border-radius: 24px; overflow: hidden; background: linear-gradient(180deg,#2563eb,#7c3aed); color: white; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
      .header { padding: 36px; display:flex; align-items:center; justify-content:space-between; }
      .header .title { font-size:28px; font-weight:700; }
      .content { display:flex; padding: 32px; gap: 32px; }
      .left { width: 260px; }
      .photo { width: 180px; height:180px; border-radius:12px; background:#fff; padding:6px; }
      .photo img { width:100%; height:100%; object-fit:cover; border-radius:8px; }
      .qr { margin-top:20px; width:160px; height:160px; background:#fff; padding:8px; border-radius:12px; }
      .right { flex:1; color:#fff; }
      .voter-id { font-size:22px; font-weight:800; margin-bottom:12px; }
      .label { font-size:12px; opacity:0.9; }
      .value { font-size:18px; font-weight:600; margin-bottom:10px; }
      .two-cols { display:flex; gap:20px; }
      .footer { padding: 24px; text-align:center; background: rgba(255,255,255,0.05); font-size:12px; }
    </style>
  </head>
  <body>
    <div class="card">
      <div class="header">
        <div class="title">VOTER IDENTIFICATION CARD</div>
        <div style="font-size:14px; opacity:0.9">ElectionHub Digital Platform</div>
      </div>
      <div class="content">
        <div class="left">
          <div class="photo">${photoSrc ? `<img src="${photoSrc}"/>` : ''}</div>
          <div class="qr"><img src="${qrDataUrl}" style="width:100%;height:100%;object-fit:contain"/></div>
        </div>
        <div class="right">
          <div class="voter-id">${voter.voterId}</div>
          <div style="margin-bottom:16px"><div class="label">Full Name</div><div class="value">${voter.name}</div></div>
          <div class="two-cols">
            <div style="flex:1"><div class="label">Date of Birth</div><div class="value">${voter.dateOfBirth || 'N/A'}</div></div>
            <div style="flex:1"><div class="label">Registration Date</div><div class="value">${voter.registrationDate || 'N/A'}</div></div>
          </div>
          <div style="margin-top:12px"><div class="label">Email</div><div class="value">${voter.email}</div></div>
          <div style="margin-top:12px"><div class="label">Address</div><div class="value">${voter.address || 'N/A'}</div></div>
          <div class="two-cols" style="margin-top:12px">
            <div style="flex:1"><div class="label">Constituency</div><div class="value">${voter.constituency || 'N/A'}</div></div>
            <div style="flex:1"><div class="label">Polling Station</div><div class="value">${voter.pollingStation || 'N/A'}</div></div>
          </div>
        </div>
      </div>
      <div class="footer">Issued: ${issueDate} • This is an official digital voter identification card. Keep it secure and present during voting.</div>
    </div>
  </body>
  </html>`;
}

// Try to locate a Chrome/Edge executable on the host (useful on Windows)
function findChromeExecutable() {
  const envPaths = [process.env.PUPPETEER_EXECUTABLE_PATH, process.env.CHROME_PATH, process.env.CHROME_BIN, process.env.CHROME_EXE];
  const candidates = [];

  // Environment variables (if set)
  for (const p of envPaths) if (p) candidates.push(p);

  // Common Windows install locations
  if (os.platform() === 'win32') {
    const local = process.env.LOCALAPPDATA || '';
    const programFiles = process.env.PROGRAMFILES || '';
    const programFilesx86 = process.env['PROGRAMFILES(X86)'] || '';
    candidates.push(path.join(local, 'Google', 'Chrome', 'Application', 'chrome.exe'));
    candidates.push(path.join(programFiles, 'Google', 'Chrome', 'Application', 'chrome.exe'));
    candidates.push(path.join(programFilesx86, 'Google', 'Chrome', 'Application', 'chrome.exe'));
    // Edge fallback
    candidates.push(path.join(local, 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
  } else {
    // macOS / Linux common paths
    candidates.push('/usr/bin/google-chrome');
    candidates.push('/usr/bin/chromium-browser');
    candidates.push('/usr/bin/chromium');
    candidates.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
  }

  for (const c of candidates) {
    try {
      if (c && fs.existsSync(c)) return c;
    } catch (e) {
      // ignore
    }
  }
  return null;
}

// Generate PDF from HTML using Puppeteer for pixel-perfect layout
async function generatePDFWithPuppeteer(html) {
  const launchOptions = { args: ['--no-sandbox', '--disable-setuid-sandbox'] };
  const exe = findChromeExecutable();
  if (exe) {
    launchOptions.executablePath = exe;
    console.log('[generatePDFWithPuppeteer] Using browser executable:', exe);
  } else if (process.env.PUPPETEER_EXECUTABLE_PATH) {
    launchOptions.executablePath = process.env.PUPPETEER_EXECUTABLE_PATH;
    console.log('[generatePDFWithPuppeteer] Using PUPPETEER_EXECUTABLE_PATH:', process.env.PUPPETEER_EXECUTABLE_PATH);
  } else {
    console.warn('[generatePDFWithPuppeteer] No local Chrome/Edge detected and PUPPETEER_EXECUTABLE_PATH not set. Puppeteer will attempt to use its bundled Chromium or fail.');
  }

  const browser = await puppeteer.launch(launchOptions);
  try {
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true, margin: { top: '20px', bottom: '20px', left: '20px', right: '20px' } });
    await page.close();
    return pdfBuffer;
  } finally {
    await browser.close();
  }
}

// Endpoint to generate voter ID and send via email
app.post('/api/send-voter-id', async (req, res) => {
  const { voter } = req.body || {};
  
  console.log('[/api/send-voter-id] Processing request for voter:', voter?.voterId);

  // Validation
  if (!voter) {
    return res.status(400).json({ error: 'Missing voter data' });
  }

  if (!voter.email) {
    return res.status(400).json({ error: 'Voter email is required' });
  }

  if (!voter.voterId || !voter.name) {
    return res.status(400).json({ error: 'Missing required voter fields: voterId, name' });
  }

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(voter.email)) {
    return res.status(400).json({ error: 'Invalid email format' });
  }

  try {
    // Check SMTP configuration
    const smtpHost = process.env.SMTP_HOST;
    const smtpUser = process.env.SMTP_USER;
    const smtpPass = process.env.SMTP_PASS;
    const fromEmail = process.env.FROM_EMAIL;

    if (!smtpHost || !smtpUser || !smtpPass) {
      console.error('[/api/send-voter-id] SMTP configuration missing');
      console.log('[/api/send-voter-id] Expected env vars: SMTP_HOST, SMTP_USER, SMTP_PASS, FROM_EMAIL');
      return res.status(500).json({ 
        error: 'Email service not configured. Please contact the administrator.',
        details: 'SMTP credentials are missing on the server'
      });
    }

    console.log('[/api/send-voter-id] Generating QR code...');
    // Generate QR code
    const qrData = {
      id: voter.voterId,
      name: voter.name,
      email: voter.email,
      dob: voter.dateOfBirth,
      reg: voter.registrationDate,
      timestamp: new Date().toISOString(),
      checksum: Buffer.from(voter.voterId + voter.email).toString('base64')
    };

    const qrCodeBuffer = await generateQRCode(qrData);
    console.log('[/api/send-voter-id] QR code generated');

    console.log('[/api/send-voter-id] Generating PDF (puppeteer HTML render)...');
    // Generate PDF by rendering HTML that matches the frontend UI
    const qrDataUrl = 'data:image/png;base64,' + qrCodeBuffer.toString('base64');
    const voterCardHTML = renderVoterCardHTML(voter, qrDataUrl);
    const pdfBuffer = await generatePDFWithPuppeteer(voterCardHTML);
    console.log('[/api/send-voter-id] PDF generated (puppeteer), size:', pdfBuffer.length, 'bytes');

    // Generate voter card image (PNG)
    console.log('[/api/send-voter-id] Generating card image preview...');
    const voterCardImage = await generateVoterCardImage(voter, qrCodeBuffer);
    console.log('[/api/send-voter-id] Card image generated');

    // Setup email transporter
    console.log('[/api/send-voter-id] Setting up email transporter...');
    const transporter = nodemailer.createTransport({
      host: smtpHost,
      port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 587,
      secure: process.env.SMTP_SECURE === 'true',
      auth: { 
        user: smtpUser, 
        pass: smtpPass 
      },
      connectionTimeout: 10000,
      socketTimeout: 15000,
      logger: true,
      debug: true,
      tls: {
        rejectUnauthorized: false
      }
    });

    // Verify SMTP connection (optional - just for logging)
    console.log('[/api/send-voter-id] Testing SMTP connection...');
    try {
      await transporter.verify();
      console.log('[/api/send-voter-id] SMTP connection verified successfully');
    } catch (verifyErr) {
      // Don't fail on verification - try to send anyway
      console.warn('[/api/send-voter-id] SMTP verification warning (non-blocking):', verifyErr.message);
    }

    // Generate HTML email content
    const htmlContent = generateEmailHTML(voter, voterCardImage);

    // Send email
    console.log('[/api/send-voter-id] Sending email to:', voter.email);
    const mailOptions = {
      from: fromEmail || smtpUser,
      to: voter.email,
      subject: `Your Voter ID Card - ${voter.voterId}`,
      html: htmlContent,
      text: `Your voter ID card has been generated. Your Voter ID: ${voter.voterId}. Voter Name: ${voter.name}.`,
      attachments: [
        {
          filename: `voter-id-${voter.voterId}.pdf`,
          content: pdfBuffer,
          contentType: 'application/pdf'
        }
      ]
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('[/api/send-voter-id] Email sent successfully. Message ID:', info.messageId);

    res.json({ 
      success: true, 
      message: `Voter ID sent successfully to ${voter.email}`,
      messageId: info.messageId
    });

  } catch (err) {
    console.error('[/api/send-voter-id] ❌ FULL ERROR DETAILS:');
    console.error('Error Message:', err.message);
    console.error('Error Code:', err.code);
    console.error('Error Stack:', err.stack);
    console.error('Full Error Object:', JSON.stringify(err, null, 2));
    
    res.status(500).json({ 
      error: 'Failed to send voter ID',
      details: err.message || 'Unknown error',
      code: err.code
    });
  }
});

app.listen(5000, ()=> {
  console.log('\n' + '='.repeat(60));
  console.log('✅ VOTING BACKEND SERVER STARTED');
  console.log('='.repeat(60));
  console.log('Server: http://localhost:5000');
  console.log('Environment: ' + (process.env.NODE_ENV || 'development'));
  console.log('Database: SQLite voting.db');
  console.log('Email Config: ' + (process.env.SMTP_HOST ? '✓ Configured' : '✗ Not configured'));
  console.log('='.repeat(60) + '\n');
});
