# PDF Email Sending - Complete Verification Guide

## Quick Answer: YES, the PDF IS Really Sent to Gmail ✅

The system is designed to actually send the Voter ID PDF to the specified Gmail address using real SMTP. Here's how to verify it works:

---

## Step-by-Step Verification

### 1️⃣ Install Dependencies

```bash
cd backend
npm install
```

### 2️⃣ Configure Gmail

#### For Gmail Users:

**Important:** You MUST use an **App Password**, not your regular Gmail password.

**Get App Password:**
1. Go to https://myaccount.google.com/apppasswords
2. Make sure 2-Factor Authentication is enabled first
3. Select "Mail" and "Windows Computer"
4. Google generates a 16-character password
5. Copy the password (remove spaces if any)

**Update .env file:**
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-actual-email@gmail.com
SMTP_PASS=your16characterpassword
FROM_EMAIL=your-actual-email@gmail.com
```

Example with real credentials:
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=john.doe@gmail.com
SMTP_PASS=abcdefghijklmnop
FROM_EMAIL=john.doe@gmail.com
```

### 3️⃣ Test Email Configuration

Before sending voter IDs, test if your setup works:

```bash
npm run test-email
```

**Expected Output:**
```
✓ .env file found
✓ All required environment variables are set
✓ SMTP connection successful!
✓ Test email sent successfully!

================================
✅ ALL TESTS PASSED - SYSTEM READY
================================
```

**If test email appears in your inbox:** ✅ System is working!

**If test fails:** See Troubleshooting section below.

### 4️⃣ Start Backend Server

```bash
npm start
```

You should see:
```
Connected to SQLite database
Backend running on http://localhost:5000
```

### 5️⃣ Send a Test Voter ID

Use **Postman** or **curl**:

#### Option A: Using Postman
1. Create POST request: `http://localhost:5000/api/send-voter-id`
2. Headers: `Content-Type: application/json`
3. Body (JSON):
```json
{
  "voter": {
    "voterId": "VID-2025-TEST001",
    "name": "John Doe",
    "email": "your-test-email@gmail.com",
    "dateOfBirth": "1990-05-15",
    "address": "123 Main Street",
    "constituency": "District 1",
    "pollingStation": "School A",
    "registrationDate": "2025-02-11"
  }
}
```

#### Option B: Using curl
```bash
curl -X POST http://localhost:5000/api/send-voter-id \
  -H "Content-Type: application/json" \
  -d '{
    "voter": {
      "voterId": "VID-2025-TEST001",
      "name": "John Doe",
      "email": "your-test-email@gmail.com",
      "dateOfBirth": "1990-05-15",
      "address": "123 Main Street",
      "constituency": "District 1",
      "pollingStation": "School A",
      "registrationDate": "2025-02-11"
    }
  }'
```

### 6️⃣ Check Your Gmail

✅ **Success Indicators:**
- Email received in Gmail inbox (from sender address)
- Subject: "Your Voter ID Card - VID-2025-TEST001"
- Contains professional HTML formatted email
- Contains PDF attachment: "voter-id-VID-2025-TEST001.pdf"
- PDF shows voter information, photo area, and QR code

📧 **Response from API:**
```json
{
  "success": true,
  "message": "Voter ID sent successfully to your-test-email@gmail.com",
  "messageId": "<unique-message-id@gmail.com>"
}
```

---

## What Gets Sent in the Email

### 1. Professional HTML Email
- Header with ElectionHub branding
- Voter ID prominently displayed
- Voter information (name, email, DOB, constituency, polling station)
- Instructions on how to use the voter ID
- Security notices
- Footer with contact information

### 2. PDF Attachment
The PDF file includes:
- Voter photo (if provided)
- QR code for verification
- All voter details nicely formatted
- Professional layout with colors
- Issue date
- Security footer

---

## Troubleshooting

### Problem: "SMTP verification failed"
**Solution 1: Wrong Password**
- Make sure you're using the **App Password**, not regular Gmail password
- App Passwords are 16 characters without spaces
- Get it from: https://myaccount.google.com/apppasswords

**Solution 2: 2FA Not Enabled**
- Go to https://myaccount.google.com/security
- Enable "2-Step Verification"
- Then generate App Password

**Solution 3: .env Not Loaded**
- Restart backend server after updating .env
- Make sure .env is in the backend folder

### Problem: "SMTP connection ENOTFOUND"
**Causes:**
- No internet connection
- Firewall blocking SMTP port 587
- Wrong SMTP_HOST

**Solutions:**
- Check internet connection
- Disable firewall temporarily to test
- Verify SMTP_HOST is: `smtp.gmail.com` for Gmail

### Problem: Test email not received
**Check:**
1. Spam/Junk folder in Gmail
2. Check backend console for errors
3. Verify recipient email is correct
4. Wait a few seconds (emails take time)

### Problem: "Missing voter data" Error
**Solution:**
Make sure your POST request body includes required fields:
- voterId ✓
- name ✓
- email ✓
- dateOfBirth (optional but recommended)
- address (optional but recommended)
- constituency (optional but recommended)
- pollingStation (optional but recommended)
- registrationDate (optional but recommended)

### Problem: Email sent but no PDF attachment
**Check:**
- Server console logs for PDF generation errors
- Verify backend has enough memory
- Check if recipient email filters are blocking attachments

---

## Real-World Usage Example

When used in your voting application:

1. Admin approves voter registration ✓
2. Admin generates voter ID ✓
3. Admin clicks "Send Voter ID" button ✓
4. Frontend sends POST request to backend ✓
5. Backend:
   - Generates QR code ✓
   - Creates PDF with all details ✓
   - Composes HTML email ✓
   - Connects to Gmail SMTP ✓
   - Sends email with PDF attachment ✓
6. Voter receives email in Gmail inbox ✓
7. Voter downloads PDF and saves it ✓

---

## Testing Checklist

- [ ] Dependencies installed (`npm install`)
- [ ] .env file created with Gmail credentials
- [ ] App Password generated from Google Account
- [ ] Test email sent successfully (`npm run test-email`)
- [ ] Test email received in Gmail inbox
- [ ] Backend server running (`npm start`)
- [ ] Test voter ID sent via API
- [ ] Voter ID email received in inbox
- [ ] PDF attachment is present
- [ ] PDF opens and displays correctly
- [ ] HTML email is properly formatted

---

## Alternative Email Providers

### Outlook/Hotmail:
```env
SMTP_HOST=smtp-mail.outlook.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@outlook.com
SMTP_PASS=your-password
FROM_EMAIL=your-email@outlook.com
```

### Yahoo Mail:
```env
SMTP_HOST=smtp.mail.yahoo.com
SMTP_PORT=467
SMTP_SECURE=true
SMTP_USER=your-email@yahoo.com
SMTP_PASS=your-app-password
FROM_EMAIL=your-email@yahoo.com
```

---

## Security Best Practices

🔒 **Important:**
1. Never commit `.env` to Git
2. Add `.env` to `.gitignore`
3. Don't share your App Password
4. Use different app passwords for different apps
5. Revoke passwords if compromised

---

## Support

If emails still don't send after all steps:
1. Check backend console logs carefully
2. Verify internet connection
3. Try sending from a different Gmail account
4. Check Gmail security settings allow IMAP access

The system **DOES send real PDFs** to real Gmail addresses when properly configured! 🎉
